<?php if(!defined('BASEPATH')) exit('No direct script access allowed');







class contentstatus_model extends Base_model

{

    public $table = "current_status";

    var $column_order = array(null, 'page_url','meta_title','date','status'); //set column field database for datatable orderable

    var $column_search = array('page_url','meta_title','date','status'); //set column field database for datatable searchable 

    var $order = array('id' => 'asc'); // default order



        



        function __construct() {



            parent::__construct();



        }







     function delete($id) {



        $this->db->where('id', $id);



        $this->db->delete($this->table);        



        return $this->db->affected_rows();



    }







    public function find($id) {



            $query = $this->db->select('*')



                    ->from($this->table)



                    ->where('id', $id)



                    ->get();



            if ($query->num_rows() > 0) {



                $result = $query->result();



                return $result[0];



            } else {



                return array();



            }



        }



       // Get  List

        function get_datatables()

        {

            $this->_get_datatables_query();

            if(isset($_POST['length']) && $_POST['length'] != -1)

            $this->db->limit($_POST['length'], $_POST['start']);

            $query = $this->db->get();

            return $query->result();

        }

        // Get Database 

         public function _get_datatables_query()

        {     

            $this->db->from($this->table);

            $i = 0;     

            foreach ($this->column_search as $item) // loop column 

            {

                if(isset($_POST['search']['value']) && $_POST['search']['value']) // if datatable send POST for search

                {

                    if($i===0) // first loop

                    {

                        $this->db->like($item, $_POST['search']['value']);

                    }

                    else

                    {

                        $this->db->or_like($item, $_POST['search']['value']);

                    }

                }

                $i++;

            }

             

            if(isset($_POST['order'])) // here order processing

            {

                $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);

            } 

            else if(isset($this->order))

            {

                $order = $this->order;

                $this->db->order_by(key($order), $order[key($order)]);

            }

        }



        // Count  Filtered

        function count_filtered()

        {

            $this->_get_datatables_query();

            $query = $this->db->get();

            return $query->num_rows();

        }

        // Count all
        public function count_all()
        {

            $this->db->from($this->table);

            return $this->db->count_all_results();

        }

        // save & update table
        public function currentSave($user_id, $data)
        {
            date_default_timezone_set("Asia/Calcutta");
            // define date
            $hours = date("H");
            if($hours >= 14){
                $date  = date('Y-m-d');
                $datefrom  = date('Y-m-d'). " 12:01:00";
                $dateto    = date("Y-m-d",strtotime("tomorrow")). " 11:59:00";
            }else{
                $date  = date('Y-m-d',strtotime("yesterday"));
                $datefrom  = date('Y-m-d',strtotime("yesterday")). " 12:01:00";
                $dateto    = date("Y-m-d"). " 11:59:00";
            }

            // get login data 
            $sql = "SELECT * FROM current_status where date_at = '".$date."' AND user_id='".$user_id."'";
            $currentData = $this->rawQuery($sql);
            if(empty($currentData)){
                // insert query
                $insData = array();
                $insData['date_at'] =  $datefrom;
                $insData['user_id'] =  $user_id;
                $insData['login_at'] =  date("Y-m-d H:i:s");
                $insData['login_status'] =  "1";
                $insData['current_status'] =  "2";
                $insData['create_at'] =  date("Y-m-d H:i:s");
                $this->db->insert($this->table, $insData);
                return $this->db->insert_id();
            }else{
                // update query
                // login time update 
                if($data['logAction'] == 'Login'){
                    $insData = array();
                    // get login data 
                    $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user_id."' AND action_type ='1' ORDER BY id ASC ";
                    $loginData = $this->rawQuery($sql); 
                    
                    // update 
                    $loginLog = array();
                    $i = 0;
                    if(!empty($loginData))
                    foreach ($loginData as $key => $value) {
                      $loginLog['login_at'][$i] = $value->date_at;
                      $loginLog['status'][$i] = $value->status;
                      $loginLog['count'] = (isset($loginLog['count']))?$loginLog['count']+1:1;
                      $i++;
                    }
                    
                    
                    $insData['user_id'] =  $user_id;
                    $insData['login_log'] =  json_encode($loginLog,true);
                    $insData['login_at'] =  date("Y-m-d H:i:s");
                    $insData['update_at'] =  date("Y-m-d H:i:s");
                    $insData['login_status'] =  "1";
                    $insData['current_status'] =  "2";

                    $this->db->where('id', $currentData[0]->id);
                    $this->db->update($this->table, $insData);
                    $updated_status = $this->db->affected_rows();

                }// end login action condition

                // ***************************************
                // Logout
                // ***************************************
                if($data['logAction'] == 'logOut'){
                    $insData = array();
                    
                    $insData['user_id'] =  $user_id;
                    $insData['update_at'] =  date("Y-m-d H:i:s");
                    $insData['logout_at'] =  date("Y-m-d H:i:s");
                    $insData['login_status'] =  "2";
                    $insData['current_status'] =  "5";
                    $this->db->where('id', $currentData[0]->id);
                    $this->db->update($this->table, $insData);
                    $updated_status = $this->db->affected_rows();

                }// end logout action condition

                // Live status change 
                // *************************************** 
                if($data['logAction'] == 'LiveChangeStatus'){
                    //pre($data);
                    $insData = array();
                    
                    // =======================================
                    // Login Data Bind 
                    // =======================================
                    $loginLog = array();
                    $i = 0;
                    if(!empty($data['loginData']))
                    foreach ($data['loginData'] as $key => $value) {
                      $loginLog['login_at'][$i] = $value->date_at;
                      $loginLog['status'][$i] = $value->status;
                      $loginLog['total_time_sec'][$i] = intval($value->total_time_sec);
                      $loginLog['count'] = (isset($loginLog['count']))?$loginLog['count']+1:1;
                      $loginLog['totalTime'] = (isset($loginLog['totalTime']))?$loginLog['totalTime']+intval($value->total_time_sec):intval($value->total_time_sec);
                      $i++;
                    }

                    $insData['login_log'] =  json_encode($loginLog,true);
                    //End ========================================

                    // =======================================
                    // Avail Data Bind 
                    // =======================================
                    $availData = array();
                    $i = 0;
                    if(!empty($data['availData']))
                    foreach ($data['availData'] as $key => $value) {
                      $availData['login_at'][$i] = $value->date_at;
                      $availData['status'][$i] = $value->status;
                      $availData['total_time_sec'][$i] = intval($value->total_time_sec);
                      $availData['count'] = (isset($availData['count']))?$availData['count']+1:1;
                      $availData['totalTime'] = (isset($availData['totalTime']))?$availData['totalTime']+intval($value->total_time_sec):intval($value->total_time_sec);
                      $i++;
                    }
                    $insData['avail_log'] =  json_encode($availData,true);
                    //End ========================================

                    // =======================================
                    // Oncall Data Bind 
                    // =======================================
                    $oncallData = array();
                    $i = 0;
                    if(!empty($data['oncallData']))
                    foreach ($data['oncallData'] as $key => $value) {
                      $oncallData['login_at'][$i] = $value->date_at;
                      $oncallData['status'][$i] = $value->status;
                      $oncallData['total_time_sec'][$i] = intval($value->total_time_sec);
                      $oncallData['count'] = (isset($oncallData['count']))?$oncallData['count']+1:1;
                      $oncallData['totalTime'] = (isset($oncallData['totalTime']))?$oncallData['totalTime']+intval($value->total_time_sec):intval($value->total_time_sec);
                      $i++;
                    }
                    $insData['oncall_log'] =  json_encode($oncallData,true);
                    //End ========================================
                    
                    // =======================================
                    // Break Data Bind 
                    // =======================================
                    $breakData = array();
                    $i = 0;
                    if(!empty($data['breakData']))
                    foreach ($data['breakData'] as $key => $value) {
                      $breakData['login_at'][$i] = $value->date_at;
                      $breakData['status'][$i] = $value->status;
                      $breakData['total_time_sec'][$i] = intval($value->total_time_sec);
                      $breakData['count'] = (isset($breakData['count']))?$breakData['count']+1:1;
                      $breakData['totalTime'] = (isset($breakData['totalTime']))?$breakData['totalTime']+intval($value->total_time_sec):intval($value->total_time_sec);
                      $i++;
                    }
                   
                    $insData['break_log'] =  json_encode($breakData,true);
                    //End ========================================
                    $insData['user_id'] =  $user_id;
                    
                    $insData['update_at'] =  date("Y-m-d H:i:s");
                    $insData['login_status'] =  "1";
                    if(isset($data['current_status']))
                    $insData['current_status'] = $data['current_status'];
                    //pre($insData);exit;
                    $this->db->where('id', $currentData[0]->id);
                    $this->db->update($this->table, $insData);
                    $updated_status = $this->db->affected_rows();

                }// end login action condition
            }
        }



        // get Live Eployee data
        // save & update table
        public function getLiveData()
        {
            date_default_timezone_set("Asia/Calcutta");
            // define date
            $hours = date("H");
            if($hours >= 14){
                $date  = date('Y-m-d');
                $datefrom  = date('Y-m-d'). " 12:01:00";
                $dateto    = date("Y-m-d",strtotime("tomorrow")). " 11:59:00";
            }else{
                $date  = date('Y-m-d',strtotime("yesterday"));
                $datefrom  = date('Y-m-d',strtotime("yesterday")). " 12:01:00";
                $dateto    = date("Y-m-d"). " 11:59:00";
            }

            // get login data 
            $sql = "SELECT u.*, cs.id as currentId, cs.* FROM users as u JOIN current_status as cs ON cs.user_id = u.id where cs.date_at = '".$date."' ";
            return $currentData = $this->rawQuery($sql);
            
            

        }// close function



}