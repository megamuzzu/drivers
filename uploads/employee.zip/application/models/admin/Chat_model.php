<?php if(!defined('BASEPATH')) exit('No direct script access allowed');







class Chat_model extends Base_model
{

    public $table = "chat";

    //set column field database for datatable orderable
    var $column_order = array(null, 'name', 'slug', 'status'); 

    //set column field database for datatable searchable 
    var $column_search = array('name'); 

    var $order = array('id' => 'asc'); // default order
        function __construct() {
            parent::__construct();
        }
     function delete($id) {



        $this->db->where('id', $id);



        $this->db->delete($this->table);        



        return $this->db->affected_rows();



    }







    public function find($id) {
            $query = $this->db->select('*')
                    ->from($this->table)
                    ->where('id', $id)
                    ->get();

            if ($query->num_rows() > 0) {
                $result = $query->result();
                return $result[0];
            } else {
                return array();
            }
        }

       // Get  List

        function get_datatables()
        {

            $this->_get_datatables_query();

            if(isset($_POST['length']) && $_POST['length'] != -1)

            $this->db->limit($_POST['length'], $_POST['start']);

            $query = $this->db->get();

            return $query->result();

        }

        // Get Database 

         public function _get_datatables_query()
        {     

            $this->db->from($this->table);

            $i = 0;     

            foreach ($this->column_search as $item) // loop column 

            {

                if(isset($_POST['search']['value']) && $_POST['search']['value']) // if datatable send POST for search

                {

                    if($i===0) // first loop

                    {

                        $this->db->like($item, $_POST['search']['value']);

                    }

                    else

                    {

                        $this->db->or_like($item, $_POST['search']['value']);

                    }

                }

                $i++;

            }

             

            if(isset($_POST['order'])) // here order processing
            {

                $this->db->order_by($this->column_order[$_POST['order']['0']['column']], $_POST['order']['0']['dir']);

            } 

            else if(isset($this->order))

            {

                $order = $this->order;

                $this->db->order_by(key($order), $order[key($order)]);

            }

        }



        // Count  Filtered

        function count_filtered()
        {

            $this->_get_datatables_query();

            $query = $this->db->get();

            return $query->num_rows();

        }

        // Count all

        public function count_all()
        {

            $this->db->from($this->table);

            return $this->db->count_all_results();

        }

         
        // getChatList
        public function getChatList($LoginUserId,$chatWith)
        {

            $newChat = $this->getNewChat($LoginUserId);
            //pre($newChat);
            
            $onlineStatus = $this->getOnlineStatus();
          
            date_default_timezone_set("Asia/Calcutta");
            // get login data 
            //$sql  = "SELECT u.id, u.name, u.img, u.designation, u.department, u.login_at FROM `users` as u LEFT JOIN chat as c ON (u.id = c.user2) WHERE u.status = '1' GROUP BY c.user2  Order By c.id DESC";
            $whereInGroup = '["'.$LoginUserId.'"]';
            $sql  = "SELECT u.id, u.name, u.img,u.type, u.designation, u.department, u.login_at FROM `users` as u  WHERE (type in ('2,1') OR JSON_CONTAINS(groupUsers, '".$whereInGroup."')) AND u.status = '1'  ";
            $dbData = $this->rawQuery($sql);

            
            // creat list
            //======================================================
            $topUl = '<ul class="list-unstyled" >';
            $topMess = '';
            $topOnline = '';
            $listBar = '';
            foreach ($dbData as $k => $v) {
            if($v->id != $LoginUserId){
                if(!empty($v->name))
                $profileImage = !empty($v->img)?$v->img:'user.png';
                $activeClass = ($chatWith == $v->id)?" active ":"";
                $desig = (isset($designation[$v->designation]))?$designation[$v->designation]:'';
                $newChatCount = isset($newChat[$v->id])?$newChat[$v->id]:'';
                $status = ((isset($onlineStatus[$v->id]['status']) && $onlineStatus[$v->id]['status'] == 1) OR $v->type == 5) ?"online":"offline";
                $LastSeen = (isset($onlineStatus[$v->id]['status']) && $onlineStatus[$v->id]['status'] != 1)?$onlineStatus[$v->id]['lastSeen']:'';
                $tempList = '<li class=" userList  '.$activeClass.' " data-id="'.$v->id.'" data-name="'.$v->name.'" data-type="'.$v->type.'" >
                    <div class="row">
                        <div class="col-2">
                            <img src="'.base_url()."assets/images/employee/".$profileImage.'" class="profileListImage" width="40" />
                            <span id="loginStatusBades'.$v->id.'" class="onlineStatusBudge '.$status.'" title="" >0</span>
                        </div>
                        <div class="col-9">
                            <div class="userNameCon">   
                                <p class="lineHeight0 chatUserName" >'.$v->name.'</p>
                                <p class="lineHeight0 text-secondary"><small>'.$desig.'&nbsp;&nbsp;<span class="lastSeen" id="lastSeen'.$v->id.'"></span> </small></p>
                            </div>  
                        </div>
                        <div class="col-1">     
                           <span id="chageBades'.$v->id.'" class="chageBadesSpan badge badge-success" >'.$newChatCount.'</span>
                        </div>
                    </div>  
                </li>';
                    if($status == 'online')
                    {
                        $topOnline .= $tempList; 
                    }else if(!empty($newChatCount)){
                        $topMess .= $tempList;
                    }else{
                        $listBar .= $tempList;
                    }

                 }  
            }

            return $listSidebar = $topUl.$topOnline.$topMess.$listBar."</ul>";
        }

        //End Chat user List ================================================

        // Get Chat Content ================================================
        public function getChatContent($LoginUserId,$chatWith){
            $myId = $LoginUserId;
            $sql  = "SELECT * FROM `chat` WHERE (user1 = '".$myId."' AND user2 = '".$chatWith."') OR (user1 = '".$chatWith."' AND user2 = '".$myId."') ORDER BY id DESC LIMIT 0,30";
                // update status   
                $sqlCheck  = "SELECT * FROM `chat` WHERE (user1 = '".$myId."' AND user2 = '".$chatWith."' AND msgstatus = '0') OR (user1 = '".$chatWith."' AND user2 = '".$myId."' AND seenat = '0000-00-00 00:00:00') ORDER BY id DESC LIMIT 0,30";
                $result = $this->rawQuery($sqlCheck);
                if(count($result) < 1){
                    //exit;
                }else{

                    $sqlUpdate1 = "UPDATE `chat` SET `msgstatus`=1 WHERE user1 = '".$myId."' AND user2 = '".$chatWith."' AND msgstatus = '0'";
                    $sqlUpdate2 = "UPDATE `chat` SET `seenat`='".date("Y-m-d H:i:s")."' WHERE user1 = '".$chatWith."' AND user2 = '".$myId."' AND seenat = '0000-00-00 00:00:00'";
                    $this->rawUpdate($sqlUpdate1);
                    $this->rawUpdate($sqlUpdate2);
                }


           
            $chatData = '';
            $result = $this->rawQuery($sql);
            $result = array_reverse($result);
            foreach ($result as $row) {

                //$chatData[$row['id']] = $row;
                $classIs = ($row->user1 == $LoginUserId)?"me":"you";
                $chatData .= '<div class="row chatText"><div class="col-12"><div class="chatRow my-1" ><div class="chatContent  '.$classIs.' " ><p class="UserTitle hidden"><small>User Name</small></p><p class="chatMsg">'.base64_decode($row->msg).'</p><p class="chatTime">'.$row->dateat.'</p></div></div></div></div>';
            }

            if(empty($chatData)){
                $chatData ='<div class=""><h2 class="text-center noHaveChat" >No Have Chat Conversation</h2></div>';
            }
            return $chatData;
        }// end chat function
        //End  Get Chat Content ================================================

        // getNewChat
        public function getNewChat($LoginUserId)
        {
            date_default_timezone_set("Asia/Calcutta");
            $this->onlineSessionUpdate($LoginUserId);
            // get login data 
            $sql  = "SELECT user1, count(*) as newChat  FROM chat WHERE chat.user2 = '$LoginUserId' AND seenat = '0000-00-00 00:00:00' GROUP BY user1";
            $dbData = $this->rawQuery($sql);
            $users = array();
            if(!empty($dbData))
            foreach ($dbData as  $row) {
                $users[$row->user1] = $row->newChat;
            }
            return $users;
        }
        // update online status
        // insert update online session
        function onlineSessionUpdate($myid)
        {
            date_default_timezone_set("Asia/Calcutta");
            $dateTime =  date("Y-m-d H:i:s");
            $dateat =  date("Y-m-d");
            // check session
            $selectSql = "SELECT * FROM `onlinestatus` WHERE userid = '".$myid."' ORDER BY  id DESC ";
            $rowData = $this->rawQuery($selectSql);
            if(empty($rowData)  )
            {
                $queryStatus = "insert";
            }else
            {
                $rowData = $rowData[0];
                if($rowData->sessionEnd == '0000-00-00 00:00:00')
                {
                    $queryStatus = "update";
                }else{
                    $datetime1 = strtotime($rowData->sessionEnd);
                    $datetime2 = strtotime($dateTime);
                    $interval  = abs($datetime2 - $datetime1);
                    $diffMinutes   = round($interval / 60);
                    if($diffMinutes <= '3')
                    {
                        $queryStatus = "update";
                    }
                    else{
                        $queryStatus = "insert";        
                    }
                }

            }
            // insert Query
            if(isset($queryStatus) && $queryStatus == 'insert'){
                $data = array();
                $data['userid'] = $myid;
                $data['sessionStart'] = $dateTime;
                $data['sessionEnd'] = '';
                $data['dateat'] = $dateat;
                $this->db->insert('onlinestatus', $data);
                return $this->db->insert_id();

            }
            // update Query
            if(isset($queryStatus) && $queryStatus == 'update'){
                $loginHours = $this->dateDiffMin($rowData->sessionStart,$rowData->sessionEnd);
                $data = array();
                $data['sessionEnd'] = $dateTime;
                $data['loginHours'] = $loginHours;
                $this->db->where('id',$rowData->id );
                $this->db->update('onlinestatus', $data);
                
            }

        }// end function

        // functions GetOnline Status
        public function getOnlineStatus(){
            $dateTime =  date("Y-m-d H:i:s");
            $sql = "SELECT userid, sessionEnd FROM onlinestatus WHERE id IN (SELECT MAX(id) FROM onlinestatus GROUP BY userid )";
            $rowData = $this->rawQuery($sql);
            $onlineData = array();
            if(!empty($rowData))
            foreach($rowData as $row )
            {
                $diff = $this->dateDiffMin($row->sessionEnd,$dateTime);
                $onlineData[$row->userid]['lastSeen'] = ($this->lastSeenDateFormate($diff))?$this->lastSeenDateFormate($diff):$row->sessionEnd;
                $onlineData[$row->userid]['status'] = ($diff <= 3)?1:0;
            
            }

            return $onlineData;
        }

        // date difference in minuts
        public function dateDiffMin($dateStart,$dateEnd){
            $datetime1 = strtotime($dateStart);
            $datetime2 = strtotime($dateEnd);
            $interval  = abs($datetime2 - $datetime1);
            $diffMinutes   = round($interval / 60);
            return $diffMinutes;
        }

        // 
        // lastSeenDateFormate
        public function lastSeenDateFormate($diff)
        {       
            if($diff < 4)
            {
                $dateDiffFormate = "online";
            }else if($diff <= 59)
            {
                $dateDiffFormate = $diff." Min";
            }else if($diff > 59 && $diff < 1439)
            {
                $dateDiffFormate = ($diff/60)." Hours";
            }else{
                $dateDiffFormate = false;
            }
            return $dateDiffFormate;
        }
       



}











  