<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

//require APPPATH . '/libraries/BaseController.php';


/**
 * Class : User (UserController)
 * User Class to control all user related operations.

 * @since : 15 November 2016
 */
class Dashboard extends CI_Controller
{
    
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('admin/users_model');
        $this->load->model('admin/punchstatus_model');
        $this->load->model('admin/contentstatus_model');
        $this->load->model('admin/chat_model');
        $this->load->library('base_library');
        // Cookie helper
        $this->load->helper('cookie');
     }



    /**
     * Index Page for this controller.
     */
    // Index =============================================================
    public function index()
    {
        //session_start();
        //session_destroy();exit;

        date_default_timezone_set("Asia/Calcutta");
        $form_data = $this->input->post();
        $data = array();
        $user = $this->session->get_userdata();
        if(!isset($user['empId'])){
            header("Location:".base_url());
        }

        // get user data
        $where = array();
        $where['id'] = $user['empId'];
        $returnData = $this->users_model->findDynamic($where);
        
        // define date
        $hours = date("H");
        if($hours >= 14){
        $datefrom  = date('Y-m-d'). " 12:01:00";
        $dateto    = date("Y-m-d",strtotime("tomorrow")). " 11:59:00";
        }else{
            $datefrom  = date('Y-m-d',strtotime("yesterday")). " 14:45:00";
            $dateto    = date("Y-m-d"). " 11:59:00";
        }

        // get login data 
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='1' AND status = '1' ORDER BY id ASC ";
        $loginData = $this->users_model->rawQuery($sql);

        // get avail data 
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='2'  ORDER BY id desc";
        $availData = $this->users_model->rawQuery($sql);
        
        $availTime = array();
        $availTime['count'] = 0;
        $availTime['total'] = 0;
        $availTime['session'] = array();
        if(!empty($availData))
        foreach ($availData as $v) {
            $availTime['total'] =  $availTime['total']+diffTime($v->date_at,$v->end_date_at);
            $availTime['session'][] = diffTime($v->date_at,$v->end_date_at);
            $availTime['count']++;
        }
        $data['listAvail']   =$availTime;

        // get oncall Data  
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='3'  ORDER BY id desc";
        $oncallData = $this->users_model->rawQuery($sql);

        $oncallTime = array();
        $oncallTime['count'] = 0;
        $oncallTime['total'] = 0;
        $oncallTime['session'] = array();
        if(!empty($oncallData))
        foreach ($oncallData as $v) {
            $oncallTime['total'] =  $oncallTime['total']+diffTime($v->date_at,$v->end_date_at);
            $oncallTime['session'][] = diffTime($v->date_at,$v->end_date_at);
            $oncallTime['count']++;
        }
        $data['listOncall']   =$oncallTime;


        // get Break Data  
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='4'  ORDER BY id desc";
        $breakData = $this->users_model->rawQuery($sql);

        $breakTime = array();
        $breakTime['count'] = 0;
        $breakTime['total'] = 0;
        $breakTime['session'] = array();
        if(!empty($breakData))
        foreach ($breakData as $v) {
            $breakTime['total'] =  $breakTime['total']+diffTime($v->date_at,$v->end_date_at);
            $breakTime['session'][] = diffTime($v->date_at,$v->end_date_at);
            $breakTime['count']++;
        }
        $data['listBreak']   =$breakTime;


        // get last envent
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."'  ORDER BY id desc LIMIT 1";
        //exit;
        $lastevent = $this->users_model->rawQuery($sql);


       // login diff in second
        $time1 = date("Y-m-d H:i:s");
        $time2 = (isset($loginData[0]->date_at))?$loginData[0]->date_at:'';
        $data['loginSec'] = round((strtotime($time1) - strtotime($time2)), 1);

        



      // Save Current Data ============================= 
        $user_id = $user['empId'];
        $saveData = array();
        $saveData['loginData'] = $loginData;
        $saveData['availData'] = $availData;
        $saveData['oncallData'] = $oncallData;
        $saveData['breakData'] = $breakData;
        $saveData['logAction'] = 'LiveChangeStatus';
        $this->contentstatus_model->currentSave($user_id, $saveData);

      // Onload Comon Page Data ============================= 
        // get all action 
        $data['action_type'] = $this->config->item('action_type') ;

       // Define =========================== 
       $data['loginData'] = $loginData[0];
       $data['availData'] = $availData;
       $data['oncallData'] = $oncallData;
       $data['breakData'] = $breakData;
       $data['lastevent'] = empty($lastevent)?'':$lastevent[0];


       $data["user"]=$returnData[0];
       $data["title"]="WebsiteName";
       $data["file"]="front/dashboard";
       $this->load->view('front/header/template',$data);
    }  

    // change status by ajax
    public function changeStatus()
    {
        date_default_timezone_set("Asia/Calcutta");
        $form_data = $this->input->post();
        
        // row where change status
        // get Break Data  
        $sql = "SELECT * FROM punch_status where user_id='".$form_data['user_id']."' AND action_type='".$form_data['old_action_type']."'  AND status = '1' ORDER BY id desc";
        $udateRow = $this->users_model->rawQuery($sql);
        if(empty($udateRow)){
           echo "error";exit;
        }
        $udateRow = $udateRow[0];
        
        // update row
        $total_time_sec = round((strtotime(date("Y-m-d H:i:s")) - strtotime($udateRow->date_at)), 1);    

        $insertData = array();
        $insertData['id'] = $udateRow->id;
        $insertData['status'] = 2;
        $insertData['last_update_time'] = date("H:i:s");
        $insertData['end_date_at'] = date("Y-m-d H:i:s");
        $insertData['total_time_sec'] = $total_time_sec;
        $this->punchstatus_model->save($insertData);
        
        // insert new row for new acction 
        $insertData = array();
        $insertData['user_id'] = $form_data['user_id'];
        $insertData['action_type'] = $form_data['action_type'];
        $insertData['start_date_at'] = date("Y-m-d");
        $insertData['start_time_at'] = date("H:i:s");
        $insertData['last_update_time'] = date("H:i:s");
        $insertData['date_at'] = date("Y-m-d H:i:s");
        $insertData['status'] = "1";
        $this->punchstatus_model->save($insertData);
        echo "success";
    }

    // Logout
    public function Logout()
    {
        date_default_timezone_set("Asia/Calcutta");
        $form_data = $this->input->post();
        
        // row where change status
        // get Break Data  
        $sql = "SELECT * FROM punch_status where user_id='".$form_data['user_id']."' AND action_type='".$form_data['old_action_type']."'  AND status = '1' ORDER BY id desc";
        $udateRow = $this->users_model->rawQuery($sql);
        if(empty($udateRow)){
           echo "error";exit;
        }
        
        $udateRow = $udateRow[0];
        
        // update row
        $total_time_sec = round((strtotime(date("Y-m-d H:i:s")) - strtotime($udateRow->date_at)), 1);    

        $insertData = array();
        $insertData['id'] = $udateRow->id;
        $insertData['status'] = 2;
        $insertData['last_update_time'] = date("H:i:s");
        $insertData['end_date_at'] = date("Y-m-d H:i:s");
        $insertData['total_time_sec'] = $total_time_sec;
        $this->punchstatus_model->save($insertData);

        // update login status
        $insertData = array();
        $insertData['id'] = $form_data['loginId'];
        $insertData['last_update_time'] = date("H:i:s");
        $insertData['end_date_at'] = date("Y-m-d H:i:s");
        $insertData['status'] = "2";
        $this->punchstatus_model->save($insertData);
        $this->session->sess_destroy();

        // save current table data
        $user_id = $form_data['user_id'];
        $saveData = array();
        $saveData['logAction'] = 'logOut';
        $this->contentstatus_model->currentSave($user_id, $saveData);

        echo "success";
    }


    // get data in 10 second
    public function getdata()
    {
        date_default_timezone_set("Asia/Calcutta");
        $form_data = $this->input->post();
        $data = array();
        $user = $this->session->get_userdata();
        if(!isset($user['empId'])){
            header("Location:".base_url());
        }

        // update query current data
        // get Break Data  
        $sql = "SELECT * FROM punch_status where user_id='".$form_data['user_id']."' AND action_type='".$form_data['action_type']."'  AND status = '1' ORDER BY id desc";
        $udateRow = $this->users_model->rawQuery($sql);
        if(!empty($udateRow)){
           $udateRow = $udateRow[0];
        
            // update row
            $total_time_sec = round((strtotime(date("Y-m-d H:i:s")) - strtotime($udateRow->date_at)), 1);    

            $insertData = array();
            $insertData['id'] = $udateRow->id;
            $insertData['status'] = 1;
            $insertData['last_update_time'] = date("H:i:s");
            $insertData['end_date_at'] = date("Y-m-d H:i:s");
            $insertData['total_time_sec'] = $total_time_sec;
            $this->punchstatus_model->save($insertData);
        }// update query end    

        // get user data
        $where = array();
        $where['id'] = $user['empId'];
        $returnData = $this->users_model->findDynamic($where);
        
        // define date
        $hours = date("H");
        if($hours >= 14){
        $datefrom  = date('Y-m-d'). " 12:01:00";
        $dateto    = date("Y-m-d",strtotime("tomorrow")). " 11:59:00";
        }else{
            $datefrom  = date('Y-m-d',strtotime("yesterday")). " 14:45:00";
            $dateto    = date("Y-m-d"). " 11:59:00";
        }

        // update login data 
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='1'  ORDER BY id desc ";
        $loginData = $this->users_model->rawQuery($sql);
        // first update login time
        if(!empty($loginData)){
           $udateRow = $loginData[0];
            // update row
            $total_time_sec = round((strtotime(date("Y-m-d H:i:s")) - strtotime($udateRow->date_at)), 1);    

            $insertData = array();
            $insertData['id'] = $udateRow->id;
            $insertData['status'] = 1;
            $insertData['last_update_time'] = date("H:i:s");
            $insertData['end_date_at'] = date("Y-m-d H:i:s");
            $insertData['total_time_sec'] = $total_time_sec;
            $this->punchstatus_model->save($insertData);
        }
       
        // get login data 
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='1'  ORDER BY id desc ";
        $loginData = $this->users_model->rawQuery($sql);
        $loginTime = array();
        $loginTime['count'] = 0;
        $loginTime['total'] = 0;
        $loginTime['session'] = array();
        if(!empty($loginData))
        foreach ($loginData as $v) {
            $loginTime['total'] =  $loginTime['total']+diffTime($v->date_at,$v->end_date_at);
            $loginTime['session'][] = diffTime($v->date_at,$v->end_date_at);
            $loginTime['count']++;
        }
        $data['listAvail']   =$loginTime;



        // get avail data 
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='2'  ORDER BY id desc";
        $availData = $this->users_model->rawQuery($sql);
        
        $availTime = array();
        $availTime['count'] = 0;
        $availTime['total'] = 0;
        $availTime['session'] = array();
        if(!empty($availData))
        foreach ($availData as $v) {
            $availTime['total'] =  $availTime['total']+diffTime($v->date_at,$v->end_date_at);
            $availTime['session'][] = diffTime($v->date_at,$v->end_date_at);
            $availTime['count']++;
        }
        $data['listAvail']   =$availTime;

        // get oncall Data  
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='3'  ORDER BY id desc";
        $oncallData = $this->users_model->rawQuery($sql);

        $oncallTime = array();
        $oncallTime['count'] = 0;
        $oncallTime['total'] = 0;
        $oncallTime['session'] = array();
        if(!empty($oncallData))
        foreach ($oncallData as $v) {
            $oncallTime['total'] =  $oncallTime['total']+diffTime($v->date_at,$v->end_date_at);
            $oncallTime['session'][] = diffTime($v->date_at,$v->end_date_at);
            $oncallTime['count']++;
        }
        $data['listOncall']   =$oncallTime;
        // get Break Data  
        $sql = "SELECT * FROM punch_status where (date_at between '".$datefrom."' and '".$dateto."') AND user_id='".$user['empId']."' AND action_type ='4'  ORDER BY id desc";
        $breakData = $this->users_model->rawQuery($sql);

        $breakTime = array();
        $breakTime['count'] = 0;
        $breakTime['total'] = 0;
        $breakTime['session'] = array();
        if(!empty($breakData))
        foreach ($breakData as $v) {
            $breakTime['total'] =  $breakTime['total']+diffTime($v->date_at,$v->end_date_at);
            $breakTime['session'][] = diffTime($v->date_at,$v->end_date_at);
            $breakTime['count']++;
        }
        $data['listBreak']   =$breakTime;

        // Save Current Data ============================= 
        $user_id = $user['empId'];
        $saveData = array();
        $saveData['loginData'] = $loginData;
        $saveData['availData'] = $availData;
        $saveData['oncallData'] = $oncallData;
        $saveData['breakData'] = $breakData;
        $saveData['current_status'] = $form_data['action_type'];
        $saveData['logAction'] = 'LiveChangeStatus';
        $this->contentstatus_model->currentSave($user_id, $saveData);


        // Start Chat code ************************************************
        $user = $this->session->get_userdata();
        $LoginUserId = $user['empId'];
        $chatWith = $this->input->post('chatWith');

        // insert new chat
        if(isset($form_data['content']) && !empty($form_data['content']))
        {
          $contArr = explode('<<>>', $form_data['content']);
          if(!empty($contArr)){
              foreach ($contArr as $v) {
                if(!empty($v)){
                // insert query
                    $insertData = array();
                    $insertData['user1'] = $LoginUserId;
                    $insertData['user2'] = $chatWith;
                    $insertData['msg'] = base64_encode($v);
                    $insertData['date_time'] = date("Y-m-d H:i:s");
                    $insertData['dateat'] = date("Y-m-d");
                    $insertData['timeat'] = date("H:i:s");
                    $insertData['msgstatus'] = '0';
                    $this->chat_model->save($insertData);
                    
                } // end empty condition
              }// end foreach    
           }// end if        

        }// end if

        //=====================================
        //$this->chat_model->onlineSessionUpdate($LoginUserId);
        $data['listSidebar'] = $this->chat_model->getChatList($LoginUserId,$chatWith);
        $data['chatData'] = $this->chat_model->getChatContent($LoginUserId,$chatWith);
        $data['chatRing'] = $this->chat_model->getNewChat($LoginUserId);
        //pre($LoginUserId);
        //End  Start Chat code ************************************************
        
        

        echo json_encode($data,true);
    } 

}

?>