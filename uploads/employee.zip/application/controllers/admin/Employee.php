<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class Employee extends BaseController
{
   
    public function __construct()
    {
        parent::__construct();
       $this->load->model('admin/users_model');
    }

    
    public function index()
    {
        $this->isLoggedIn();

        $data = array();
        $this->global['pageTitle'] = 'Employee  : WebsiteName';
        $this->loadViews("admin/employee/list", $this->global, $data , NULL);
        
    }

    // Add New 
    public function addnew()
    {
    
        $this->isLoggedIn();
        $data = array();
        $this->global['pageTitle'] = 'Add New Employee  : WebsiteName';
        $this->loadViews("admin/employee/addnew", $this->global, $data , NULL);
        
    } 

    // Insert Member *************************************************************
    public function insertnow()
    {
        $this->isLoggedIn();
		
		$this->load->library('form_validation');            
        $this->form_validation->set_rules('name','name','trim|required');
        $this->form_validation->set_rules('email','Email','trim|required');
        $this->form_validation->set_rules('password','Password','trim|required');
        
        
        //form data 
        $form_data  = $this->input->post();
        if($this->form_validation->run() == FALSE)
        {
            $this->addnew();
        }
        else
        {

            // check already exist
            $where = array();
            $where['email'] = $form_data['email'];
            $returnData = $this->users_model->findDynamic($where);
            if(!empty($returnData)){
               $this->session->set_flashdata('error', $form_data['name'].' already Exist.');
            }else{
                //pre($form_data);exit;
                $insertData['name'] = $form_data['name'];
                $insertData['email'] = $form_data['email'];
                $insertData['department'] = $form_data['department'];
                $insertData['designation'] = $form_data['designation'];
                $insertData['phone'] = $form_data['phone'];
                $insertData['address'] = $form_data['address'];
                $insertData['password'] = $form_data['password'];
                $insertData['status'] = $form_data['status'];
                $insertData['type'] = "2";
                $insertData['date_at'] = date("Y-m-d H:i:s");

                if(isset($_FILES['img']['name']) && $_FILES['img']['name'] != '') {

                $f_name         =$_FILES['img']['name'];
                $f_tmp          =$_FILES['img']['tmp_name'];
                $f_size         =$_FILES['img']['size'];
                $f_extension    =explode('.',$f_name);
                $f_extension    =strtolower(end($f_extension));
                $f_newfile      =uniqid().'.'.$f_extension;
                $store          ="assets/images/employee/".$f_newfile;
            
                if(!move_uploaded_file($f_tmp,$store))
                {
                    $this->session->set_flashdata('error', 'Flag Upload Failed .');
                }
                else
                {
                   $insertData['img'] = $f_newfile;
                   
                }
             }
                                  
    			$result = $this->users_model->save($insertData);
                if($result > 0)
                {
                    $this->session->set_flashdata('success', 'Employee  successfully Added');
                }
                else
                { 
                    $this->session->set_flashdata('error', 'Employee  Addition failed');
                }
            }// check already    
            redirect('admin/employee/addnew');
          }  
        
    }


    // Member list
    public function ajax_list()
    {
		$list = $this->users_model->get_datatables();
		
		$data = array();
        $no =(isset($_POST['start']))?$_POST['start']:'';
        foreach ($list as $currentObj) {
            if($currentObj->type != 1){
            $temp_date = $currentObj->date_at;
            $selected = ($currentObj->status == 0)?" selected ":"";
            $btn = '<select class="statusBtn" name="statusBtn" data-id="'.$currentObj->id.'">';
            $btn .= '<option value="1"  >Active</option>';
            $btn .= '<option value="0" '.$selected.' >Inactive</option>';
            $btn .= '</select>';
            $dateAt = date("d-m-Y H:ia", strtotime($temp_date));
            $image = empty($currentObj->img)?"user.png":$currentObj->img;

            $no++;
            $row = array();
            $row[] = $no;
            $row[] = '<img src ="'.base_url().'assets/images/employee/'.$image.'" width="30" alt = "WebsiteName"/>';
            $row[] = $currentObj->name;
            //$row[] = ($currentObj->type == 1)?"Admin":"Employee";
            $row[] = $currentObj->email;
            $row[] = $currentObj->phone;
            $row[] = $currentObj->address;
            $row[] = $currentObj->password;
            $row[] = $dateAt;
            $row[] = $btn;
            $row[] = '<a class="btn btn-sm btn-info" href="'.base_url().'admin/employee/edit/'.$currentObj->id.'" title="Edit" ><i class="fa fa-pencil"></i></a>&nbsp;<a class="btn btn-sm btn-danger deletebtn" href="#" data-userid="'.$currentObj->id.'"><i class="fa fa-trash"></i></a>';
            $data[] = $row;
            }
        }
 
        $output = array(
                        "draw" => (isset($_POST['draw']))?$_POST['draw']:'',
                        "recordsTotal" => $this->users_model->count_all(),
                        "recordsFiltered" => $this->users_model->count_filtered(),
                        "data" => $data,
                );
        //output to json format
        echo json_encode($output);
    }


    // Status Change
 
    public function statusChange($id = NULL)
    {
        $this->isLoggedIn();
        if($_POST['id'] == null)
        {
            redirect('admin/employee');
        }

        $insertData['id'] = $_POST['id'];
        $insertData['status'] = $_POST['status'];
        $result = $this->users_model->save($insertData);
        exit;
    } 

    // Edit
 
    public function edit($id = NULL)
    {
        

        $this->isLoggedIn();
        if($id == null)
        {
            redirect('admin/employee');
        }

        $data['edit_data'] = $this->users_model->find($id);
        $this->global['pageTitle'] = 'Employee  ';
        $this->loadViews("admin/employee/edit", $this->global, $data , NULL);
        
    } 

    // Delete  *****************************************************************
      function delete()
    {
        
        $this->isLoggedIn();
        $delId = $this->input->post('id');  
        
        $result = $this->users_model->delete($delId); 
            
        if ($result > 0) { echo(json_encode(array('status'=>TRUE))); }
        else { echo(json_encode(array('status'=>FALSE))); }
    }

    // Update Employee *************************************************************
    public function update()
    {
		
        $this->isLoggedIn();
        $this->load->library('form_validation');            
        $this->form_validation->set_rules('name','name','trim|required');
        $this->form_validation->set_rules('email','Email','trim|required');
        $this->form_validation->set_rules('password','Password','trim|required');
        
        
        //form data 
        $form_data  = $this->input->post();
        if($this->form_validation->run() == FALSE)
        {
			
                $this->edit($form_data['id']);
        }
        else
        {
                $insertData['id'] = $form_data['id'];
                $insertData['name'] = $form_data['name'];
                $insertData['email'] = $form_data['email'];
                $insertData['department'] = $form_data['department'];
                $insertData['designation'] = $form_data['designation'];
                $insertData['phone'] = $form_data['phone'];
                $insertData['address'] = $form_data['address'];
                $insertData['password'] = $form_data['password'];
                $insertData['status'] = $form_data['status'];
                $insertData['type'] = "2";
                $insertData['update_at'] = date("Y-m-d H:i:s");
			
			if(isset($_FILES['img']['name']) && $_FILES['img']['name'] != '') {

				$f_name         =$_FILES['img']['name'];
                $f_tmp          =$_FILES['img']['tmp_name'];
                $f_size         =$_FILES['img']['size'];
                $f_extension    =explode('.',$f_name);
                $f_extension    =strtolower(end($f_extension));
                $f_newfile      =uniqid().'.'.$f_extension;
                $store          ="assets/images/employee/".$f_newfile;
            
                if(!move_uploaded_file($f_tmp,$store))
                {
                    $this->session->set_flashdata('error', 'Flag Upload Failed .');
                }
                else
                {
					$file = "assets/images/employee/".$form_data['old_img'];
					if(file_exists ( $file))
					{
						unlink($file);
					}
					$insertData['img'] = $f_newfile;
                   
                }
             }
             

            $result = $this->users_model->save($insertData);
			

            if($result > 0)
            {
                $this->session->set_flashdata('success', ' Employee  successfully Updated');
            }
            else
            { 
                $this->session->set_flashdata('error', 'Employee  Updation failed');
            }
            redirect('admin/employee/edit/'.$insertData['id']);
          }  
        
    }

    
    
    
}

?>