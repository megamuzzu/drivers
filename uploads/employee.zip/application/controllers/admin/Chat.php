<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

require APPPATH . '/libraries/BaseController.php';


class Chat extends BaseController
{
   
    public function __construct()
    {
       parent::__construct();
        $this->load->model('admin/users_model');
        $this->load->model('admin/punchstatus_model');
        $this->load->model('admin/contentstatus_model');
        $this->isLoggedIn(); 
    }

    
    public function index()
    {
        $data = array();
        
        // footer define 
        $this->global['pageTitle'] = $this->config->item('websitename').': Message';
        $this->global['bootstrap4'] = '1';

        $this->loadViews("admin/chat/list", $this->global, $data , NULL);
        
    }


    // get chat data
    public function getdata()
    {
        $this->load->model('admin/chat_model');
        $data = array();
        // Start Chat code ************************************************
        $user = $this->session->get_userdata();
        $LoginUserId = $user['userId'];
        $chatWith = $this->input->post('chatWith');

        // insert new chat
        if(isset($form_data['content']) && !empty($form_data['content']))
        {
          $contArr = explode('<<>>', $form_data['content']);
          if(!empty($contArr)){
              foreach ($contArr as $v) {
                if(!empty($v)){
                // insert query
                    $insertData = array();
                    $insertData['user1'] = $LoginUserId;
                    $insertData['user2'] = $chatWith;
                    $insertData['msg'] = base64_encode($v);
                    $insertData['date_time'] = date("Y-m-d H:i:s");
                    $insertData['dateat'] = date("Y-m-d");
                    $insertData['timeat'] = date("H:i:s");
                    $insertData['msgstatus'] = '0';
                    $this->chat_model->save($insertData);
                    
                } // end empty condition
              }// end foreach    
           }// end if        

        }// end if

        //=====================================
        //$this->chat_model->onlineSessionUpdate($LoginUserId);
        $data['listSidebar'] = $this->chat_model->getChatList($LoginUserId,$chatWith);
        $data['chatData'] = $this->chat_model->getChatContent($LoginUserId,$chatWith);
        $data['chatRing'] = $this->chat_model->getNewChat($LoginUserId);
        //pre($LoginUserId);
        //End  Start Chat code ************************************************
        
        

        echo json_encode($data,true);
    }


    // Creat new group
    public function creategroup()
    {
        $this->load->model('admin/chat_model');
        $data = array();
        // Start Chat code ************************************************
        $user = $this->session->get_userdata();
        $LoginUserId = $user['userId'];
        $chatWith = $this->input->post('chatWith');

        $sql  = "SELECT u.id, u.name, u.img, u.designation, u.department, u.login_at FROM `users` as u  WHERE u.type = '2' && u.status = '1' && u.id != '".$LoginUserId."' ";
        $data['listSidebar'] = $this->chat_model->rawQuery($sql);
        
        
        //End  Start Chat code ************************************************
        // footer define 
        $this->global['pageTitle'] = $this->config->item('websitename').': Create New Group';
        $this->global['bootstrap4'] = '1';

        $this->loadViews("admin/chat/add-new-group", $this->global, $data , NULL);
        

        
    }


    // edit
    public function edit()
    {
        $this->load->model('admin/chat_model');
        $data = array();
        // Start Chat code ************************************************
        $user = $this->session->get_userdata();
        $LoginUserId = $user['userId'];
        $chatWith = $this->input->post('chatWith');
        $id = $_GET['id'];

        $sql  = "SELECT u.id, u.name, u.img, u.designation, u.department, u.login_at FROM `users` as u  WHERE u.type = '2' && u.status = '1' && u.id != '".$LoginUserId."' ";
        $data['listSidebar'] = $this->chat_model->rawQuery($sql);

        // get group data
        $where = array();
        $where['id'] = $id;
        $where['table'] = 'users';
        $rData = $this->chat_model->findDynamic($where);
        if(empty($rData)){
            echo "Something went wrong!";
            exit;
        }else{
            $data['user'] = $rData[0];
        }


        
        
        //End  Start Chat code ************************************************
        // footer define 
        $this->global['pageTitle'] = $this->config->item('websitename').': Create New Group';
        $this->global['bootstrap4'] = '1';

        $this->loadViews("admin/chat/add-new-group", $this->global, $data , NULL);
        

        
    }

    // Insert Group
    public function add()
    {
        $data = array();
        // Start Chat code ************************************************
        $user = $this->session->get_userdata();
        $LoginUserId = $user['userId'];
        $chatWith = $this->input->post('chatWith');

        $groupName = $this->input->post('groupName');
        $tempUser = $this->input->post('users');
        $tempUser[] = $LoginUserId;
        $groupUsers = json_encode($tempUser,true);
        

        // insert Proccess
        //pre($form_data);exit;
        if(isset($_POST['id']))
            $insertData['id'] = $_POST['id'];
        $insertData['name'] = $groupName;
        $insertData['groupUsers'] = $groupUsers;
        $insertData['status'] = '1';
        $insertData['type'] = "5";
        $insertData['date_at'] = date("Y-m-d H:i:s");

        if(isset($_FILES['img']['name']) && $_FILES['img']['name'] != '') {

            $f_name         =$_FILES['img']['name'];
            $f_tmp          =$_FILES['img']['tmp_name'];
            $f_size         =$_FILES['img']['size'];
            $f_extension    =explode('.',$f_name);
            $f_extension    =strtolower(end($f_extension));
            $f_newfile      =uniqid().'.'.$f_extension;
            $store          ="assets/images/employee/".$f_newfile;
        
            if(!move_uploaded_file($f_tmp,$store))
            {
                $this->session->set_flashdata('error', 'Flag Upload Failed .');
            }
            else
            {
               $insertData['img'] = $f_newfile;
               if(isset($_POST['oldimg'])){
                    $file = "assets/images/employee/".$_POST['oldimg'];
                    if(file_exists ( $file))
                    {
                        unlink($file);
                    }
               }
            }
         }
        
        $result = $this->users_model->save($insertData);
        if($result > 0)
        {
            $this->session->set_flashdata('success', 'Group  successfully Added');
        }
        else
        { 
            $this->session->set_flashdata('error', 'Group  Addition failed');
        }

        redirect('admin/chat');
        
    }

    
    
    
    
}

?>