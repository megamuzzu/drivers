<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

//require APPPATH . '/libraries/BaseController.php';


/**
 * Class : User (UserController)
 * User Class to control all user related operations.

 * @since : 15 November 2016
 */
class Index extends CI_Controller
{
    
    /**
     * This is default constructor of the class
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('admin/users_model');
        $this->load->model('admin/punchstatus_model');
        $this->load->model('admin/contentstatus_model');
        $this->load->library('base_library');
        // Cookie helper
        $this->load->helper('cookie');
     }



    /**
     * Index Page for this controller.
     */
    // Index =============================================================
    public function index()
    {
        
        // user login condition
       $user = $this->session->get_userdata();
        if(isset($user['empId'])){
            header("Location:".base_url('dashboard'));
        }

        
      // Onload Comon Page Data ============================= 
    	$data = array();
       // Define =========================== 
       $data["title"]="WebsiteName";
       $data["file"]="front/index";
       $this->load->view('front/header/template',$data);
    }  

    public function login()
    {
        date_default_timezone_set("Asia/Calcutta");
        $form_data = $this->input->post();

        // check already exist
        $where = array();
        $where['email'] = $form_data['email'];
        $where['password'] = $form_data['password'];
        $where['type'] = 2;
        $where['status'] = 1;
        $returnData = $this->users_model->findDynamic($where);
        if(!empty($returnData)){
            $insertData = array();
            $insertData['id'] = $returnData[0]->id;
            $insertData['login_status'] = "1";
            $insertData['login_at'] = date("Y-m-d H:i:s");
            $this->users_model->save($insertData);
            $newdata = array(
                   'empId'  => $returnData[0]->id,
                   'name'     => $returnData[0]->name,
                   'email'     => $returnData[0]->email,
                   'phone'     => $returnData[0]->phone,
                   'role'     => $returnData[0]->type,
                   'logged_in' => TRUE
               );
            $this->session->set_userdata($newdata);
            // punch status update
            $insertData = array();
            $insertData['user_id'] = $returnData[0]->id;
            $insertData['action_type'] = "1";
            $insertData['start_date_at'] = date("Y-m-d");
            $insertData['start_time_at'] = date("H:i:s");
            $insertData['last_update_time'] = date("H:i:s");
            $insertData['date_at'] = date("Y-m-d H:i:s");
            $insertData['status'] = "1";
            $this->punchstatus_model->save($insertData);
            //exit;
            // punch status update
            $insertData = array();
            $insertData['user_id'] = $returnData[0]->id;
            $insertData['action_type'] = "2";
            $insertData['start_date_at'] = date("Y-m-d");
            $insertData['start_time_at'] = date("H:i:s");
            $insertData['last_update_time'] = date("H:i:s");
            $insertData['date_at'] = date("Y-m-d H:i:s");
            $insertData['status'] = "1";
            $this->punchstatus_model->save($insertData);
            // save current table data
            $user_id = $returnData[0]->id;
            $saveData = array();
            $saveData['logAction'] = 'Login';
            $this->contentstatus_model->currentSave($user_id, $saveData);

           echo "Success";
        }else{
            echo "Error";
         }
        
    } 

}

?>