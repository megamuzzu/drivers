                  <table class="table">
                    <thead class="thead-dark">
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">DP</th>
                        <th scope="col">ID</th>
                        <th scope="col">Name</th>
                        <th scope="col">LoginAt</th>
                        <th scope="col">Current</th>
                        <th scope="col">Login</th>
                        <th scope="col">Avail</th>
                        <th scope="col">On Call</th>
                        <th scope="col">Break</th>
                        <th scope="col">Chat</th>
                      </tr>
                    </thead>
                    <tbody>
                    <?php $i = 1;
                    $actionType = $this->config->item('action_type');
                    $bg = $this->config->item('bgList');
                    if(empty($list)){ ?>
                      <tr>
                        <td scope="col">Today, no have login employee.</td>
                        
                      </tr>
                   <?php }
                    foreach($list as $v){
                      //$currentStatus = '<span class="p-2 badge bg-'.$bg[$v->current_status].'">'.$actionType[$v->current_status].'</span>';
                      $currentStatus = '<span class="p-2 badge bg-'.$bg[$v->current_status].'">'.$actionType[$v->current_status].'</span>';
                      // Login
                      $dblogin = json_decode($v->login_log,true);
                      $loginTime = isset($dblogin['totalTime'])?$dblogin['totalTime']:'0';
                      $count = isset($dblogin['count'])?$dblogin['count']:'0';
                      $login = '<span class="p-2 text-white badge bg-dark text-white "> <span class="badge badge-light "> '.$count.'</span> '.secondToClockWise($loginTime).'<br/></span>';


                      // avail
                      $dbAvail = json_decode($v->avail_log,true);
                      $availTime = isset($dbAvail['totalTime'])?$dbAvail['totalTime']:'0';
                      $count = isset($dbAvail['count'])?$dbAvail['count']:'0';
                      $avail = '<span class="p-2 text-white badge bg-info "> <span class="badge badge-light "> '.$count.'</span> '.secondToClockWise($availTime).'</span>';

                      // oncall
                      $dboncall = json_decode($v->oncall_log,true);
                      $oncallTime = isset($dboncall['totalTime'])?$dboncall['totalTime']:'0';
                      $count = isset($dboncall['count'])?$dboncall['count']:'0';
                      $oncall = '<span class="p-2 text-white badge bg-success "> <span class="badge badge-light "> '.$count.'</span> '.secondToClockWise($oncallTime).'</span>';

                      // Break
                      $dbbreak = json_decode($v->break_log,true);
                      $breakTime = isset($dbbreak['totalTime'])?$dbbreak['totalTime']:'0';
                      $count = isset($dbbreak['count'])?$dbbreak['count']:'0';
                      $break = '<span class="p-2 text-white badge bg-success "> <span class="badge badge-light "> '.$count.'</span> '.secondToClockWise($breakTime).'</span>';



                     ?>


                      <tr id="tr<?=$v->user_id?>">
                        <th scope="row"><?=$i?></th>
                        <?php $img = !empty($v->img)?$v->img:'user.png'?>
                        <td><img src ="<?= base_url().'assets/images/employee/'.$img?>" class="img-fluid"  alt = "WebsiteName" width="60" /></td>
                        <td>INT00001<?=$v->user_id?></td>
                        <td class="name"><?=$v->name?></td>
                        <td><?=date("d M Y | g:i a", strtotime($v->login_at));?> </td>
                        <td><?= $currentStatus ?></td>
                        <td><?= $login ?></td>
                        <td><?= $avail ?></td>
                        <td><?= $oncall ?></td>
                        <td><?= $break ?></td>
                        <td><button type="button" class="btn-small userList" data-id="<?=$v->user_id?>" data-name="<?=$v->name?>"  >Chat Now <?= isset($newChat[$v->user_id])?'<small class="badge badge-dark" >&nbsp;&nbsp;'.$newChat[$v->user_id].'</small>':''?> </button></td>
                      </tr>
                    <?php $i++; } ?>
                      
                    </tbody>
                  </table>
               








