<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/jquery.dataTables.min.css" />
<script src="<?php echo base_url() ?>assets/js/jquery.dataTables.min.js"></script>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
      <i class="fa fa-dashboard" aria-hidden="true"></i> Employee
        <small>Add, Edit</small>
      </h1>
    </section>
    <section class="content ">
        <div class="row">
            <div class="col-sm-12 text-right">
                <div class="form-group">
                    <a class="btn btn-primary" href="<?php echo base_url(); ?>admin/employee/addnew"><i class="fa fa-plus"></i> Add New</a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-12">
              <div class="box w-100">
                <div class="box-header">
                    <h3 class="box-title">Employee List</h3>
                     <div class="box-tools">
                         
                    </div>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive tableData ">
                  <span>Please wait..</span>
                </div><!-- /.box-body -->
              </div><!-- /.box -->
            </div>
        </div>
        <?php

?>
    </section>
</div>



<!-- chat box =========================================== -->
<div class="chatBoxCon101 hidden">
  <span class="chatBoxCloseBtn" >x</span> 
  <!-- Right col chat sec-->
    <div class="col-sm-12 p-0">
      <!-- //user Profiles -->
      <div class="userProfile p-2">
        <div class="row">
          <div class="col-sm-8">
            <h3 class="profileUserTitle" >User Name</h3>
          </div>
          <div class="col-sm-4">
            <img src="<?php echo base_url();?>assets/images/employee/user.png" width="45" class="pull-right" /> 
          </div>

        </div> 
      </div>
      <!-- //user Profiles -->
      <!-- chat content Box-->
      <div class="chatContentBox p-3">
        <div class="coverDiv">
        <div class="">
          <div class="text-center noHaveChat" ><img src="<?php echo base_url();?>assets/images/livechat.png" class="img-fluid" ></div>
        </div>
        
        </div>
      </div>

      <!--Botton repaly box-->
      <div class="replyBoxCon hidden"> 
        <form name="chatForm" id="chatForm" method="post" accept="">
          <div class="textBoxDiv">
            <div class="row"> 
              <div class="col-9"> 
                <input type="text" class="chatInput"  name="chatInput" id="chatInput" placeholder="Write Your Text" required="required" autocomplete ="off" />              
              </div>  
              <div class="col-3"> 
                <button type="submit" name="chatSubmitBtn" id="chatSubmitBtn"><img src="<?php echo base_url();?>assets/images/send-btn.png" width="55" > </button>
              </div>  
            </div>
          </div> 
        </form>
      </div>
    </div>

    <!--// Right col chat sec-->
</div>
<!--// chat box =========================================== -->

<!--// Frist Modal =========================================== -->

<div class="firstModal hidden">
   <div class="firstModalBox">
      <h3>Hello <b>Admin!</b></h3>
      <p>Continue to intasksolution - Wrok From Home Portal</p>
      <button type="button" class="btn btn-primary closeBtnFirstModal">Yes</button>
   </div>
</div>

<script type="text/javascript">
   // fist click when login
    $(document).ready(function(){
       $(".firstModal").removeClass("hidden");
       $(".closeBtnFirstModal").click(function(){
        $(".firstModal").addClass("hidden");
       });
    });
</script>
<!--// Frist Modal =========================================== -->



  <script type="text/javascript">
  // chat ====================================================
  // define 
    window.chatwith = 0;
    window.chatContent = '';
    window.mouseOnchatBox = 0;
    window.chatAlert = new Array();

    // Auto load when page ready
    jQuery(document).ready(function(){
        loadPage30sec();
      });

    // List Chat User Select 
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".userList", function(){
            window.chatwith = jQuery(this).attr("data-id");
            name = jQuery(this).attr("data-name");
            $('.profileUserTitle').html(name);
        jQuery(".replyBoxCon").removeClass("hidden");
        $(".chatBoxCon101").removeClass("hidden");
      });
    });

    // Close Chat Bos
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".chatBoxCloseBtn", function(){
            $(".chatBoxCon101").addClass("hidden");
            window.chatwith = '';
      });
    });

    // if hover chat text box then not update
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".chatText", function(){
            window.mouseOnchatBox = 1;
            setTimeout(function() {
              window.mouseOnchatBox = 0;
          }, 5000);
      });
    });
    

    // chat submit ajax
    jQuery(document).ready(function(){
          jQuery(document).on("submit", "#chatForm", function(){
            var msgtext = jQuery("#chatInput").val();
            var chatwith = window.chatwith;
            if(chatwith == '')
            {
              alert("First Select Chat User");
              return false; 
            }
            if(msgtext == '')
            {
              alert("Write Your Message");
              return false; 
            }
            window.chatContent = (window.chatContent != '')?window.chatContent+"<<>>"+msgtext:msgtext;
            jQuery("#chatInput").val('');
            $('.chatContentBox').scrollTop($('.chatContentBox')[0].scrollHeight);
            return false;
      });
    });

  //Script chat ==============================================
</script>



<script type="text/javascript">
  // ever 30 second
    $(document).ready(function(){
      loadPage30sec();
    });
    // auto refresh
    function loadPage30sec(){
        var user_id = "<?= $this->session->userdata('userId') ?>";
        var lastContent = window.chatContent;
        window.chatContent = '';
        $.ajax(
        {
          type:"POST",
          url:'<?= base_url("admin/dashboard/liveList")?>',
          data:"user_id="+user_id+'&chatWith='+window.chatwith+'&content='+lastContent,
          success:function(returnVal)
          {
            var data = $.parseJSON(returnVal);
            $(".tableData").html(data['list']);
            //$(".testTag").html("new2");
            // chat Data
            $.each( data['newChat'], function( key, value ) {
              if(window.chatAlert[key] != value  ){
                
                // audo play
                var ringtone = "<?= base_url('assets/ringtone/alert3.mp3')?>";
                var audio = new Audio(ringtone);
                audio.play();

                window.chatAlert[key] = value;
              }
              
              //$(".testTag").html(window.chatAlert[key]);
            });
           // window.chatAlert = data['newChat'];


            if(window.chatwith != 0){
              if(window.mouseOnchatBox == 0 ){
                $(".chatContentBox").html(data['chatData']);
                $('.chatContentBox').scrollTop($('.chatContentBox')[0].scrollHeight);
                window.chatAlert[window.chatwith] = 0;
             }  
           
              //window.chatContent = '';
            }
            // End chat part  ===========================
            
          }
        });
      };

    // 
    setInterval(loadPage30sec, 1000); 
  </script>







