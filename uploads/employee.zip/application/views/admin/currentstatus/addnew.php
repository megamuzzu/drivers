<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/jquery-ui.css"> 
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         <a href="<?php echo base_url();?>admin/employee"> <i class="fa fa-user" aria-hidden="true"></i> Employee</a>
        <small>Add New Employee</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- Success & Error Alert-->
            <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
            <!-- Success & Error Alert-->
            
            <div class="col-md-12">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Add New Employee</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" id="member_form" action="<?php echo base_url() ?>admin/employee/insertnow" method="post" role="form" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-4">
                                    <!--Department-->
                                    <?php $department = $this->config->item('department') ; ?>
                                    <div class="form-group">
                                         <label for="status">Department</label>
                                         <select class ="form-control" name="department" id="status">
                                            <?php foreach($department as $k=>$v){ ?>
                                            <option value="<?=$k?>"><?= $v?></option>
                                            <?php } ?>
                                        </select>   
                                    </div>

                                    <!--Designation-->
                                    <?php $designation = $this->config->item('designation') ; ?>
                                    <div class="form-group">
                                         <label for="status">Designation</label>
                                         <select class ="form-control" name="designation" id="status">
                                            <?php foreach($designation as $k=>$v){ ?>
                                            <option value="<?=$k?>"><?= $v?></option>
                                            <?php } ?>
                                        </select>   
                                    </div> 

                                    <!--Employee Name-->         
                                    <div class="form-group">
                                        <label for="name">Employee Name</label>
                                        <input type="text" id="name" name ="name" class="form-control" required="required" placeholder="*Enter Employee Name"  >
                                    </div>

									<!--Employee Thumbnail-->                             
                                    <div class="form-group">
                                        <label for="img">Employee Thumbnail</label>
                                        <input type="file" id="img" name ="img" class="form-control"  placeholder="Choose Employee Thumbnail" >
                                    </div>
                                    
                                    <!--Email-->                             
                                    <div class="form-group">
                                        <label for="email">Email</label>
                                        <input type="text" id="email" name ="email" class="form-control" required="required" placeholder="*Enter Employee Code" required >
                                    </div> 
                                    

                                    <!--Phone Number-->                             
                                    <div class="form-group">
                                        <label for="phone">Phone Number</label>
                                        <input type="text" id="phone" name ="phone" class="form-control"  placeholder="Enter Phone Number"  >
                                    </div>

                                    <!--Create Password-->       
                                    <div class="form-group">
                                        <label for="password">Create Password</label>
                                        <input type="text" id="password" name ="password" class="form-control"  placeholder="*Enter Create Password" minlength="6" required >
                                    </div>

                                    <!--Address-->       
                                    <div class="form-group">
                                        <label for="address">Address</label>
                                        <input type="text" id="address" name ="address" class="form-control"  placeholder="Full Address" >
                                    </div>

                                    <!--Status-->
                                    <div class="form-group">
                                         <label for="status">Status</label>
                                         <select class ="form-control" name="status" id="status">
                                            <option value="1">Active</option>
                                            <option value="0">Inactive</option>
                                        </select>   
                                    </div> 

                                   </div><!-- // col-md-4-->

                             </div>
                             
                             
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            
        </div>    
    </section>
    
</div>

