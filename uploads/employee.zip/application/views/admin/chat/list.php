<style type="text/css">
  .navbar-static-top{
    display: none;
  }
    ::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  ::-webkit-scrollbar-track {
    box-shadow: inset 0 0 5px grey; 
    border-radius: 10px;
  }
   
  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: green; 
    border-radius: 10px;
  }

  /* Handle on hover */
  ::-webkit-scrollbar-thumb:hover {
    background: #b30000; 
  }
</style>
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/jquery.dataTables.min.css" />
<script src="<?php echo base_url() ?>assets/js/jquery.dataTables.min.js"></script>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content p-0">
        <div class="row">
            <div class="col-sm-4 pr-0">
              <div class="p-2" style="background: #6fb4bf">
                  <div class="row">
                    <div class="col-sm-8">
                      <h3 class="profileUserTitle" >Group & Users</h3>
                    </div>
                    <div class="col-sm-4 pt-2">
                      <a href="<?= base_url('admin/chat/creategroup')?>" class="btn btn-info" title="Create New Group" ><i class="fa fa-plus"></i> </a>
                    </div>
                    <!--list-->
                    <div class="col-sm-12 px-0" id="sidebarCon" style="height: 75vh;overflow-y: scroll;">
                      
                    </div>
                    <!--//list-->


                  </div> 
                </div>
            </div>
            <div class="col-sm-8 pl-0">
              <!-- chat box =========================================== -->
                <div class="chatConBox ">
                  
                  <!-- Right col chat sec-->
                    <div class="col-sm-12 p-0">
                      <!-- //user Profiles -->
                      <div class="bg-info p-2">
                        <div class="row">
                          <div class="col-sm-8">
                            <h3><span class="profileUserTitle"></span> &nbsp;&nbsp;&nbsp;<a href="#" class="text-white hidden btnEdit"><i class="fa fa-pencil" style="font-size: 16px"></i></a></h3>
                          </div>
                          <div class="col-sm-4">
                            <img src="<?php echo base_url();?>assets/images/employee/user.png" width="45" class="pull-right" /> 
                          </div>

                        </div> 
                      </div>
                      <!-- //user Profiles -->
                      <!-- chat content Box-->
                      <div class="chatContentBox p-3">
                        <div class="coverDiv">
                        <div class="">
                          <div class="text-center noHaveChat" ><img src="<?php echo base_url();?>assets/images/livechat.png" width="300px" ></div>
                        </div>
                        
                        </div>
                      </div>

                      <!--Botton repaly box-->
                      <div class="replyBoxCon hidden" style="width: 54%;"> 
                        <form name="chatForm" id="chatForm" method="post" accept="">
                          <div class="textBoxDiv">
                            <div class="row"> 
                              <div class="col-12"> 
                                <input type="text" class="chatInput"  name="chatInput" id="chatInput" placeholder="Write Your Text" required="required" autocomplete ="off" />

                                <button type="submit" name="chatSubmitBtn" id="chatSubmitBtn" style="position: absolute; right: 8px;top: 6px;" ><img src="<?php echo base_url();?>assets/images/sendbtn.png" width="55" > </button>

                              </div>  
                              
                            </div>
                          </div> 
                        </form>
                      </div>
                    </div>

                    <!--// Right col chat sec-->
                </div>
                <!--// chat box =========================================== -->
            </div>
        </div>
        <?php

?>
    </section>
</div>





<!--// Frist Modal =========================================== -->

<div class="firstModal hidden">
   <div class="firstModalBox">
      <h3>Hello <b>Admin!</b></h3>
      <p>Continue to intasksolution - Wrok From Home Portal</p>
      <button type="button" class="btn btn-primary closeBtnFirstModal">Yes</button>
   </div>
</div>

<script type="text/javascript">
   // fist click when login
    $(document).ready(function(){
       //$(".firstModal").removeClass("hidden");
       $(".closeBtnFirstModal").click(function(){
        $(".firstModal").addClass("hidden");
       });
    });
</script>
<!--// Frist Modal =========================================== -->



  <script type="text/javascript">
  // chat ====================================================
  // define 
    window.chatwith = 0;
    window.chatContent = '';
    window.mouseOnchatBox = 0;
    window.chatAlert = new Array();

    // Auto load when page ready
    jQuery(document).ready(function(){
        loadPage30sec();
      });

    // List Chat User Select 
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".userList", function(){
            window.chatwith = jQuery(this).attr("data-id");
            name = jQuery(this).attr("data-name");
            var type = jQuery(this).attr("data-type");
            $('.profileUserTitle').html(name);
            if(type == 5){
              url  = "<?= base_url('admin/chat/edit?id=')?>";
              $('.btnEdit').removeClass("hidden");
              $('.btnEdit').attr("href",url+window.chatwith);
            }else{
              $('.btnEdit').addClass("hidden");
            }
        jQuery(".replyBoxCon").removeClass("hidden");
        $(".chatConBox").removeClass("hidden");
      });
    });

    // Close Chat Box
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".chatBoxCloseBtn", function(){
            $(".chatConBox").addClass("hidden");
            window.chatwith = '';
      });
    });

    // if hover chat text box then not update
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".chatText", function(){
            window.mouseOnchatBox = 1;
            setTimeout(function() {
              window.mouseOnchatBox = 0;
          }, 5000);
      });
    });
    

    // chat submit ajax
    jQuery(document).ready(function(){
          jQuery(document).on("submit", "#chatForm", function(){
            var msgtext = jQuery("#chatInput").val();
            var chatwith = window.chatwith;
            if(chatwith == '')
            {
              alert("First Select Chat User");
              return false; 
            }
            if(msgtext == '')
            {
              alert("Write Your Message");
              return false; 
            }
            window.chatContent = (window.chatContent != '')?window.chatContent+"<<>>"+msgtext:msgtext;
            jQuery("#chatInput").val('');
            $('.chatContentBox').scrollTop($('.chatContentBox')[0].scrollHeight);
            return false;
      });
    });

  //Script chat ==============================================
</script>



<script type="text/javascript">
  // ever 30 second
    $(document).ready(function(){
      loadPage30sec();
    });
    // auto refresh
    function loadPage30sec(){
        var user_id = "<?= $this->session->userdata('userId') ?>";
        var lastContent = window.chatContent;
        window.chatContent = '';
        $.ajax(
        {
          type:"POST",
          url:'<?= base_url("admin/chat/getdata")?>',
          data:"user_id="+user_id+'&chatWith='+window.chatwith+'&content='+lastContent,
          success:function(returnVal)
          {
            var data = $.parseJSON(returnVal);
            $("#sidebarCon").html(data['listSidebar']);
            //$(".testTag").html("new2");
            // chat Data
            $.each( data['newChat'], function( key, value ) {
              if(window.chatAlert[key] != value  ){
                
                // audo play
                var ringtone = "<?= base_url('assets/ringtone/alert3.mp3')?>";
                var audio = new Audio(ringtone);
                audio.play();

                window.chatAlert[key] = value;
              }
              
              //$(".testTag").html(window.chatAlert[key]);
            });
           // window.chatAlert = data['newChat'];


            if(window.chatwith != 0){
              if(window.mouseOnchatBox == 0 ){
                $(".chatContentBox").html(data['chatData']);
                $('.chatContentBox').scrollTop($('.chatContentBox')[0].scrollHeight);
                window.chatAlert[window.chatwith] = 0;
             }  
           
              //window.chatContent = '';
            }
            // End chat part  ===========================
            
          }
        });
      };

    // 
    setInterval(loadPage30sec, 1000); 
  </script>







