<style type="text/css">
  .navbar-static-top{
    display: none;
  }
    ::-webkit-scrollbar {
    width: 5px;
  }

  /* Track */
  ::-webkit-scrollbar-track {
    box-shadow: inset 0 0 5px grey; 
    border-radius: 10px;
  }
   
  /* Handle */
  ::-webkit-scrollbar-thumb {
    background: green; 
    border-radius: 10px;
  }

  /* Handle on hover */
  ::-webkit-scrollbar-thumb:hover {
    background: #b30000; 
  }
</style>
<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/jquery.dataTables.min.css" />
<script src="<?php echo base_url() ?>assets/js/jquery.dataTables.min.js"></script>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content pt-0 pl-0">
        <form method="post" id="myForm" action="<?= base_url('admin/chat/add')?>" enctype="multipart/form-data">
        <div class="row">
              <div class="col-sm-4 pr-0">
                <div class="p-2" style="background: #055c61">
                    <div class="row">
                      <div class="col-sm-12 from-group">
                        <label class="text-light" >Group Name </label>
                        <input type="text" name="groupName" id="groupName" placeholder="Enter Group Name " required class="form-control" value="<?= (isset($user))?$user->name:''  ?>"><br/>
                      </div>
                      <div class="col-sm-12 from-group">
                        <label class="text-light" >Upload Group DP </label>
                         <input type="file" id="img" name ="img" class="form-control"  placeholder="Choose product Image" required ><br/>
                         <?php 
                           if(isset($user)){
                            echo '<input type="hidden" name="oldimg" value="'.$user->img.'" >';
                            echo '<input type="hidden" name="id" value="'.$user->id.'" >';
                            $selectedUsers = array();
                            $temp = json_decode($user->groupUsers,true);
                            foreach ($temp as $value) {
                              $selectedUsers[$value] = " checked ";
                            }

                           }
                         ?>
                      </div>
                      <!--list-->
                      <style type="text/css">
                        .proFile{
                          border-radius: 20px;
                          height: 40px;
                          width: 40px;
                          border: 1px solid #c7c2c2;
                        }
                        .chatList li{
                          padding: 9px 2px;
                          border-bottom: 1px solid #d4caca;
                          color: #fff;
                        }
                        .addBtn{
                          cursor: pointer;
                        }
                        .addBtn:hover{
                          color:black;
                        }
                      </style>
                      <div class="col-sm-12 text-white " id="sidebarCon" style="height: 63vh;overflow-y: scroll;">
                        <p>Select Users <strong class="totalUser pull-right" ></strong></p>
                        <ul class="list-unstyled chatList">
                        <?php 

                        $i = 1;
                        foreach ($listSidebar as $k => $v) { ?>
                          <li >
                            <div class="row ">
                              <div class="col-sm-2">
                                <img src="<?= base_url('assets/images/employee/'.$v->img)?>" class="proFile" width="45" >
                              </div>
                              <div class="col-sm-8 pt-2">
                                <label for="user<?= $v->id?>">  <?= $v->name?></label>
                              </div>
                              <div class="col-sm-2 pt-2">
                                <input id="user<?= $v->id?>" class="btnUser" name="users[]" value="<?= $v->id?>" type="checkbox" <?= (isset($selectedUsers) && isset($selectedUsers[$v->id]))?$selectedUsers[$v->id]:'';  ?>  />
                              </div>
                            </div>
                          </li>  
                        <?php $i++; }  ?>
                        </ul>
                        
                      </div>
                      <div class="col-sm-12 text-white">
                        <button type="button" id="submitBtn" class="btn btn-success" >Create</button>
                      </div>
                      <!--//list-->


                    </div> 
                  </div>
              </div> 
          </div>
          </form> 


    </section>
</div>


<script type="text/javascript">
  $(document).ready(function(){
    $(".btnUser").click(function(){
      var numberOfChecked = $('input:checkbox:checked').length;
     

      $(".totalUser").html("Uesr : "+numberOfChecked);
    });


    // click submit button
    $("#submitBtn").click(function(){
      var input = $("#groupName").val();
      var numberOfChecked = $('input:checkbox:checked').length;
      if(input == '' ||  numberOfChecked == 0){
        alert("Enter Group Name & Select Users");
        return false;
      }else{
        $("#myForm").submit();
      }

    });

  });
</script>










