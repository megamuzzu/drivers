 <!-- slider start -->

  <section class="main-block">
    <div class="about-bg">
    <div class="container-fluid text-center">
        <h1>  Zeno Trading Strategy </h1>
    </div>
    </div>
  </section>
 <!-- slider end -->
 
 


<!-- section start -->
<section class="item-para">
<div class="container">
<div class="row">
<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 hover01">
   <figure><img class="img-responsive" src="<?php echo base_url();?>assets/front/images/services-unique-zeno-strategy.png" align=""  /></figure>
</div>
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
<div class="txt-para">
<h2>Our Unique Zeno Strategy</h2>
<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>


<div>
 <span id="text">
<p>
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
  </span>

</div>
<div class="btn-container">
<button id="toggle">Read More</button>
</div>

</div>



</div>
</div>
</div>


</section>
<!-- section end -->


<hr>




<!-- section start -->
<section class="item-para">
<div class="container">
<div class="row">
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
<div class="txt-para">
<h2>How It Works</h2>
<p>
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
<p>
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>

<div>
 <span id="text1">
  <p>
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
<p>
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
</p>
  </span>

</div>
<div class="btn-container">
<button id="toggle1">Read More</button>
</div>
</div>
</div>

<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 hover01">
   <figure><img class="img-responsive" src="<?php echo base_url();?>assets/front/images/service-how-it-work01.png" align=""  /></figure>
</div>
</div>

</div>
</div>


</section>
<!-- section end -->
<hr>


<!-- section start -->
<section class="item-para">
<div class="container">
<div class="row">
<div class="col-lg-4 col-sm-4 col-md-4 col-xs-12 hover01">
   <figure><img class="img-responsive" src="<?php echo base_url();?>assets/front/images/service-trading-management.jpg" align=""  /></figure>
</div>
<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
<div class="txt-para">
<h2>Trading Management</h2>
<p>"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>

<!--ul style="color:#737171; list-style:none; line-height:25px; padding-left:10px;">
    <li><i class="fa fa-angle-right"></i> A one off charge of £850 which provides the life long license for the software.</li>
    <li><i class="fa fa-angle-right"></i> A one off securities fee of £100/£1000 balance of your account .</li>
    <li><i class="fa fa-angle-right"></i> A 35% software rental fee on profits to high watermark level. </li>
    <li><i class="fa fa-angle-right"></i> No rental fee will be charged until the account has increased by £10k (For a £5k start then when it hits £10k).</li>
    </ul>-->
<div>
 <span id="text2">
<p>
"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."</p>
  </span>

</div>
<div class="btn-container">
<button id="toggle2">Read More</button>
</div>

</div>



</div>
</div>
</div>


</section>
<!-- section end -->


<script language="javascript">

// Toggele
$(document).ready(function() {
  $("#toggle").click(function() {
    var elem = $("#toggle").text();
    if (elem == "Read More") {
      //Stuff to do when btn is in the read more state
      $("#toggle").text("Read Less");
      $("#text").slideDown();
    } else {
      //Stuff to do when btn is in the read less state
      $("#toggle").text("Read More");
      $("#text").slideUp();
    }
  });
});
</script>

    <script language="javascript">
$(document).ready(function() {
  $("#toggle1").click(function() {
    var elem = $("#toggle1").text();
    if (elem == "Read More") {
      //Stuff to do when btn is in the read more state
      $("#toggle1").text("Read Less");
      $("#text1").slideDown();
    } else {
      //Stuff to do when btn is in the read less state
      $("#toggle1").text("Read More");
      $("#text1").slideUp();
    }
  });
});
</script>

<script language="javascript">
$(document).ready(function() {
  $("#toggle2").click(function() {
    var elem = $("#toggle2").text();
    if (elem == "Read More") {
      //Stuff to do when btn is in the read more state
      $("#toggle2").text("Read Less");
      $("#text2").slideDown();
    } else {
      //Stuff to do when btn is in the read less state
      $("#toggle2").text("Read More");
      $("#text2").slideUp();
    }
  });
});
</script>

<script language="javascript">
    $(document).ready(function() {
         $(".services").addClass('active');
    });
</script>