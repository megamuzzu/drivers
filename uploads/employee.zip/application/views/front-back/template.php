
<?php $this->load->view('front/header');?>


<?php $this->load->view($file); ?>

<?php $this->load->view('front/footer');?>