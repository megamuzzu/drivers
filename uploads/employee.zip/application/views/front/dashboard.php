<?php
$eventBg = "bg-info";
if(!empty($lastevent) && $lastevent->action_type == 4)
  $eventBg = "bg-warning";
else if (!empty($lastevent) && $lastevent->action_type == 3)
  $eventBg = "bg-success";
?>
<div class="alrtMesg"></div>
<section class="container-fluid" >
  <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 bg-light p-3">
          <div class="row">
            <div class="col-sm-12">
               <?php $img = !empty($user->img)?$user->img:'user.png'?>
              <img src ="<?= base_url().'assets/images/employee/'.$img?>" class="img-fluid"  alt = "WebsiteName" width="200px" />
            </div>
          </div><!-- end row-->
          <div class="row">
            <div class="col-sm-4">
              <h5>Employee Id</h5>
            </div>
            <div class="col-sm-8">
              <p>: INT00001<?= $user->id; ?></p>
            </div>
          </div><!-- end row-->
          <div class="row">
            <div class="col-sm-4">
              <h5>Name</h5>
            </div>
            <div class="col-sm-8">
              <p>: <?= $user->name; ?></p>
            </div>
          </div><!-- end row--><div class="row">
            <div class="col-sm-4">
              <h5>Phone</h5>
            </div>
            <div class="col-sm-8">
              <p>: <?= $user->phone; ?></p>
            </div>
          </div><!-- end row-->

        </div><!--//col-4-->
        <!-- col-6-->
        <div class="col-sm-6">
          <div class="row" >
            <div class="col-sm-6">
              <div class="bg-primary text-center text-white p-3  loginSessionCon cart32">
                <h3>Login Session</h3> 
                <p id="loginSession" class="fa-3x" >00:00:00</p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="<?=$eventBg?> text-center p-3 text-white currentCon cart32 ">
                <h3>Current Status</h3> 
                <p id="statusText" class="fa-3x" ><?= $action_type[$lastevent->action_type] ?></p>
              </div>
            </div>
          </div><!--//row-->
          <div class="row mt-2">
            <div class="col-sm-12">
              <div class="badge badge-info px-3">
                <h3>Avail<small class="countAvailCon" >(<?=$listAvail['count']?>)</small></h3> 
                <p id="availText" class="fa-3x" ><?=secondToClockWise($listAvail['total']);?></p>
              </div>
              <div class="badge badge-success px-3">
                <h3>Oncall<small class="countOncallCon" >(<?=$listOncall['count']?>)</small></h3> 
                <p id="oncallText" class="fa-3x" ><?=secondToClockWise($listOncall['total']);?></p>
              </div>
              <div class="badge badge-warning px-3">
                <h3>Break <small class="countBreakCon" >(<?=$listBreak['count']?>)</small></h3> 
                <p id="breackText" class="fa-3x" ><?=secondToClockWise($listBreak['total']);?></p>
              </div>
             
            </div> 
          </div><!--//row-->
          <div class="row py-4">
            <div class="col-sm-8">
              <button type="button" id="oncallBtn" class="btn actionBtn btn-success" <?= (!empty($lastevent) && $lastevent->action_type == 3)?"disabled":'' ?> data-status="3" >On Call</button>
              <button type="button" id="availBtn" class="btn actionBtn btn-info" <?= (!empty($lastevent) && $lastevent->action_type == 2)?"disabled":'' ?> data-status="2" >Avail</button>
              <button type="button" id="breakBtn" class="btn actionBtn btn-warning" <?= (!empty($lastevent) && $lastevent->action_type == 4)?"disabled":'' ?> data-status="4" >Take a break</button>
              <button type="button" id="logoutBtn" class="btn actionBtn btn-danger" >Logout</button>
            </div>
            <div class="col-sm-4">
            </div>
          </div>
        </div><!--//col-6-->
        <!--col-3 left col user listing-->
        <div class="col-sm-3 chatCon" id="sidebarCon">
          
        </div>
        <!-- //col-3 -->
      </div>
  </div> 
</section>

<!-- chat box =========================================== -->
<div class="chatBoxCon101 hidden">
  <span class="chatBoxCloseBtn" >x</span> 
  <!-- Right col chat sec-->
    <div class="col-sm-12 p-0">
      <!-- //user Profiles -->
      <div class="userProfile p-2">
        <div class="row">
          <div class="col-sm-8">
            <h3 class="profileUserTitle" >User Name</h3>
          </div>
          <div class="col-sm-4">
            <img src="<?php echo base_url();?>assets/images/employee/user.png" width="45" class="pull-right" /> 
          </div>

        </div> 
      </div>
      <!-- //user Profiles -->
      <!-- chat content Box-->
      <div class="chatContentBox p-3">
        <div class="coverDiv">
        <div class="">
          <div class="text-center noHaveChat" ><img src="<?php echo base_url();?>assets/images/livechat.png" class="img-fluid" ></div>
        </div>
        
        </div>
      </div>

      <!--Botton repaly box-->
      <div class="replyBoxCon hidden"> 
        <form name="chatForm" id="chatForm" method="post" accept="">
          <div class="textBoxDiv">
            <div class="row"> 
              <div class="col-9"> 
                <input type="text" class="chatInput"  name="chatInput" id="chatInput" placeholder="Write Your Text" required="required" autocomplete ="off" />              
              </div>  
              <div class="col-3"> 
                <button type="submit" name="chatSubmitBtn" id="chatSubmitBtn"><img src="<?php echo base_url();?>assets/images/send-btn.png" width="55" > </button>
              </div>  
            </div>
          </div> 
        </form>
      </div>
    </div>
    <!--// Right col chat sec-->
</div>
<!--// chat box =========================================== -->
<!--// Frist Modal =========================================== -->

<div class="firstModal hidden">
   <div class="firstModalBox">
      <h3>Hi <b><?= $user->name; ?> !</b></h3>
      <p>Continue to intasksolution - Wrok From Home Portal</p>
      <button type="button" class="btn btn-primary closeBtnFirstModal">Yes</button>
   </div>
</div>

<script type="text/javascript">
   // fist click when login
    $(document).ready(function(){
       $(".firstModal").removeClass("hidden");
       $(".closeBtnFirstModal").click(function(){
        $(".firstModal").addClass("hidden");
       });
    });
</script>
<!--// Frist Modal =========================================== -->





<script type="text/javascript">
  window.currentStatus = "<?= $lastevent->action_type ?>";
  function changeStatusAjax(id){
    $(".actionBtn").prop( "disabled", false );
    $("#"+id).prop( "disabled", true );
    old_action_type = window.currentStatus;
    window.currentStatus = $("#"+id).attr("data-status");
    action_type = $("#"+id).attr("data-status");
    user_id = "<?= $user->id; ?>";
    // ajax change staus
    $.ajax(
    {
      type:"POST",
      url:"<?= base_url("dashboard/changeStatus")?>",
      data:"user_id="+user_id+"&old_action_type="+old_action_type+"&action_type="+action_type,
      success:function(returnVal)
      {
        if(returnVal == 'Success'){
          
        }else{
          
        }
      }
    });// end ajax
  }

  
 $(document).ready(function(){
      // click on call button
      $("#oncallBtn").click(function(){
        changeStatusAjax("oncallBtn");
        $(".currentCon").removeClass("bg-info").removeClass("bg-success").removeClass("bg-warning").addClass("bg-success");
        $("#statusText").html("On Call");
      });

      // click on avail button
      $("#availBtn").click(function(){
        changeStatusAjax("availBtn");
        $(".currentCon").removeClass("bg-info").removeClass("bg-success").removeClass("bg-warning").addClass("bg-info");
        $("#statusText").html("Avail");
      });
      // click on break button
      $("#breakBtn").click(function(){
        changeStatusAjax("breakBtn");
        $(".currentCon").removeClass("bg-info").removeClass("bg-success").removeClass("bg-warning").addClass("bg-warning");
        $("#statusText").html("Break");
      });
  });

  // coundown function
      function startTimer(duration, display) {
        var timer = duration,hours, minutes, seconds;
        setInterval(function () {
            tempminutes = parseInt(timer / 60, 10);
            hours = parseInt(tempminutes / 60, 10);
            seconds = parseInt(timer % 60, 10);
            minutes = parseInt(tempminutes % 60, 10);

            hours   = hours   < 10 ? "0" + hours   : hours  ;
            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            display.textContent = hours + ":" +minutes + ":" + seconds;

            if (++timer < 0) {
                timer = duration;
            }
        }, 1000);
    }

    window.onload = function () {
        var fiveMinutes = "<?=$loginSec?>", // 60 * 0,
            display = document.querySelector('#loginSession');
        startTimer(fiveMinutes, display);
    };

</script>
<script type="text/javascript">
  // chat ====================================================
  // define 
    window.chatwith = 0;
    window.chatContent = '';
    window.mouseOnchatBox = 0;
    window.chatAlert = new Array();

    // Auto load when page ready
    jQuery(document).ready(function(){
        loadPage30sec();
      });

    // List Chat User Select 
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".userList", function(){
            window.chatwith = jQuery(this).attr("data-id");
            name = jQuery(this).attr("data-name");
            $('.profileUserTitle').html(name);
        jQuery(".replyBoxCon").removeClass("hidden");
        $(".chatBoxCon101").removeClass("hidden");
      });
    });

    // Close Chat Bos
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".chatBoxCloseBtn", function(){
            $(".chatBoxCon101").addClass("hidden");
            window.chatwith = '';
      });
    });

    // if hover chat text box then not update
    jQuery(document).ready(function(){
          jQuery(document).on("click", ".chatText", function(){
            window.mouseOnchatBox = 1;
            setTimeout(function() {
              window.mouseOnchatBox = 0;
          }, 5000);
      });
    });
    

    // chat submit ajax
    jQuery(document).ready(function(){
          jQuery(document).on("submit", "#chatForm", function(){
            var msgtext = jQuery("#chatInput").val();
            var chatwith = window.chatwith;
            if(chatwith == '')
            {
              alert("First Select Chat User");
              return false; 
            }
            if(msgtext == '')
            {
              alert("Write Your Message");
              return false; 
            }
            window.chatContent = (window.chatContent != '')?window.chatContent+"<<>>"+msgtext:msgtext;
            jQuery("#chatInput").val('');
            $('.chatContentBox').scrollTop($('.chatContentBox')[0].scrollHeight);
            return false;
      });
    });

  //Script chat ==============================================

  // ever 30 second
    $(document).ready(function(){
      loadPage30sec();
    });
    // auto refresh
    function loadPage30sec(){
        var user_id = "<?= $user->id; ?>";
        var lastContent = window.chatContent;
        window.chatContent = '';
        $.ajax(
        {
          type:"POST",
          url:'<?= base_url("dashboard/getdata")?>',
          data:'ajax=1&action=loadpage&action_type='+window.currentStatus+"&user_id="+user_id+'&chatWith='+window.chatwith+'&content='+lastContent,
          success:function(returnVal)
          {
            //$(".alrtMesg").html(returnVal);
            var data = $.parseJSON(returnVal);

            // avail
            $("#availText").html(secondToClock(data['listAvail']['total']));
            $(".countAvailCon").html("("+data['listAvail']['count']+")");
            // Oncall
            $("#oncallText").html(secondToClock(data['listOncall']['total']));
             $(".countOncallCon").html("("+data['listOncall']['count']+")");
             // Oncall
            $("#breackText").html(secondToClock(data['listBreak']['total']));
             $(".countBreakCon").html("("+data['listBreak']['count']+")");


            // chat part start ===========================
            $("#sidebarCon").html(data['listSidebar']);

            //chat alert 
            $.each( data['chatRing'], function( key, value ) {
              if(window.chatAlert[key] != value  ){
                
                // audo play
                var ringtone = "<?= base_url('assets/ringtone/alert3.mp3')?>";
                var audio = new Audio(ringtone);
                audio.play();

                window.chatAlert[key] = value;
              }
            });

            // chat data show 
            if(window.chatwith != 0){
              if(window.mouseOnchatBox == 0 ){
                $(".chatContentBox").html(data['chatData']);
                $('.chatContentBox').scrollTop($('.chatContentBox')[0].scrollHeight);
                window.chatAlert[window.chatwith] = 0;
             }  
             window.chatContent = '';
            }
            // End chat part  ===========================
          }
        });
      };

    // 
    setInterval(loadPage30sec, 1000 ); // 30000 = 30 sec
    // function secondtoclock
    function secondToClock(timer){
      tempminutes = parseInt(timer / 60, 10);
            hours = parseInt(tempminutes / 60, 10);
            seconds = parseInt(timer % 60, 10);
            minutes = parseInt(tempminutes % 60, 10);

            hours   = hours   < 10 ? "0" + hours   : hours  ;
            minutes = minutes < 10 ? "0" + minutes : minutes;
            seconds = seconds < 10 ? "0" + seconds : seconds;

            return hours + ":" +minutes + ":" + seconds;
    }
    

   
  </script>

  <script type="text/javascript">
  //Logout
    $(document).ready(function(){
        $("#logoutBtn").click(function(){
          old_action_type = window.currentStatus;
          user_id = "<?= $user->id; ?>";
          loginId = "<?= $loginData->id; ?>";
          // ajax change staus
          $.ajax(
          {
            type:"POST",
            url:"<?= base_url("dashboard/logout")?>",
            data:"user_id="+user_id+"&old_action_type="+old_action_type+"&loginId="+loginId,
            success:function(returnVal)
            {
              setTimeout(function() {
                    window.location.href="dashboard";
                  }, 500);
            }
          });// end ajax
        });
    });
    
   
  </script>

