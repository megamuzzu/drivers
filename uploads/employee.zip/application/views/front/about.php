
<section>
    
<div class="container-fluid">
 <div class="row">
  <img src="<?php echo base_url();?>assets/images/index/about.jpg" class="img-fluid">
    <div class="col-md-12">
    <div class="wrap-content-main text-center text-white">
  <h1><span style="font-weight:700;">About</span><span style="color:#e41e22; font-weight:700;"> Us</span></h1>

  </div>
  </div>
 </div>
</div>

</section>


<section class="bg-privacy">
<div class="container spacem wrapper-container">
 <div class="row pb-4">
 <div class="col-md-8 offset-md-2">
     <div id="scroll-1">

    <div class="policy-content">
   
        <p>WebsiteName (A wholly owned subsidiary of <strong>Sapphire Softech Solutions LLC </strong>), hereinafter known as <strong>Computeriods,</strong> is a leading IT solutions and services organization, dedicated towards creating high-quality system optimization software and utilities. Our apps are compatible with all major operating systems viz. Windows, Mac, iOS and Android. Most of our user base is based out of North America, Asia and various countries in Europe.</p>

        <p><strong>Why Choose WebsiteName?</strong></p>


        <p>WebsiteName</strong> chief motto is to simplify digital devices for even the most novice users and help them use digital devices in an efficient and hassle free way. Our range of products spans across niches like photography, music, device security and cloud backup services etc. Apart from these, we have developed a vast array of system optimization utilities that make it easy for users to maintain their device performance and optimize disk and RAM usage.</p>

        <p><strong>WebsiteName Support</strong></p>


        <p class="pb-5 about-bot">All our products are backed by a dedicated support team to address customer grievances and feedback. This enables us to constantly upgrade our services and products for an enhanced customer experience.</p>
      
    
     </div>

     
   </div>
  </div>

</section>

