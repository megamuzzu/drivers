<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">



<title><?php echo (isset($title))?$title: $this->config->item('websitename'); ?></title>
<!-- Meta Details -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="websiteName" />
<meta name="description" content="websiteName" />
<meta name="robots" content="index,follow" />
<meta name="author" content="websiteName.com" />
<meta name="copyright" content="&copy; 2018" />
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/developer/images/meta_logo.png" />
<!-- Links-->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;600;700&display=swap" rel="stylesheet">
<link href="<?php echo base_url();?>assets/bootstrap4/dist/css/bootstrap.min.css" rel="stylesheet"  />
<link href="<?php echo base_url();?>assets/css/owl.carousel.min.css" rel="stylesheet"  />
<link href="<?php echo base_url();?>assets/css/owl.theme.default.min.css" rel="stylesheet"  />
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link href="<?php echo base_url();?>assets/css/style.css" rel="stylesheet"  />
<link href="<?php echo base_url();?>assets/css/responsive.css" rel="stylesheet"  />
<link href="<?php echo base_url();?>assets/front/css/font-awesome.min.css" rel="stylesheet"  />
<script src="<?php echo base_url();?>assets/front/js/jquery-1.11.1.min.js"></script>
 <script src="<?php echo base_url();?>assets/front/js/bootstrap.min.js"></script> 

 <!-- Alertfy  -->
 <link href="<?php echo base_url();?>assets/alertfy/css/alertify.min.css" rel="stylesheet"  />
 <script src="<?php echo base_url();?>assets/alertfy/alertify.min.js"></script> 

 <!-- animate css -->
 <link href="<?php echo base_url();?>assets/animate/animate.min.css" rel="stylesheet"  />
<!-- owl carsoul -->
 <script src="<?php echo base_url();?>assets/js/owl.carousel.js"></script> 
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>


<!-- wos css-->
<link rel="stylesheet" href="<?php echo base_url();?>assets/developer/wow_js/css/libs/animate.css">
<link href="https://fonts.googleapis.com/css2?family=Source+Sans+Pro:wght@400;700;500;400;&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<link href="https://fonts.googleapis.com/css2?family=Convergence&display=swap" rel="stylesheet">

<link rel="shortcut icon" type="image/x-icon" href="<?php echo base_url();?>assets/images/favicon.png">



</head>

<body>

	