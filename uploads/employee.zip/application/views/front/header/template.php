<?php $this->load->view('front/header/header');?>
<?php $this->load->view('front/header/menu');?>
<?php $this->load->view($file); ?>
<?php $this->load->view('front/header/footer');?>