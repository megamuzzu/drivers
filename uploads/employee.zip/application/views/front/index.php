﻿<section class="container-fluid" style="background-image: url('assets/images/banner-1.png');background-size: cover;background-position: center;background-repeat: no-repeat;height: 100vh">
  <div class="container">
      <div class="col-sm-5 offset-sm-1 mt-4">
        <div class="loginCon" style=""> 
          <form method="post" action="<?= base_url('index/login') ?>" id="loginForm" >
            <div class="form-group">
              <h4 class="text-white" >Employee Login</h4>
            </div>
            <div class="form-group" id="alertCon">
            </div> 
            <div class="form-group">
              <label>Email</label>
              <input type="email" id="email" name="email" class="form-control" placeholder="Email Id" required="required">
            </div>
            <div class="form-group">
              <label>Password</label>
              <input type="password" id="password" name="password" class="form-control" placeholder="Password" required="required">
            </div> 
            <div class="form-group">
              <button type="submit" class="btn btn-primary" name="submitBtn" id="submitBtn" > Submit</button>
            </div>
          </form>
        </div>
      </div>
  </div> 
</section>
<script type="text/javascript">
  $("#loginForm").submit(function(){
    var email = $("#email").val();
    var password = $("#password").val();
    $.ajax(
    {
      type:"POST",
      url:'index/login',
      data:"email="+email+"&password="+password,
      success:function(returnVal)
      {

        if(returnVal == 'Success'){
          $("#alertCon").html('<span class="text-success">Login Success</span> ');
            setTimeout(function() {
                window.location.href="dashboard";
            }, 1000);
        }else{
          $("#alertCon").html('<span class="text-danger">Email Or Password mismatch</span> ');
        }
      }
    });
    return false;
  });
</script>